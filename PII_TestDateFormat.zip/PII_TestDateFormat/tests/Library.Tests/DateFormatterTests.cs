using System;
using TestDateFormat;

namespace Library.Tests;

public class DateFormatterTests
{
    [SetUp]
    public void Setup()
    {
    }

    [Test]
    public void FormatoCorrecto()
    {
        const string input = "12/08/2003";
        const string expected = "2003-08-11";

        string actual = DateFormatter.ChangeFormat(input);

        Assert.That(actual, Is.EqualTo(expected));
    }
    
    [Test] 
    public void TestLongitud() 
    {
        const string input = "12/08/203";
        const string expected = "";

        string actual = DateFormatter.ChangeFormat(input);

        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestFechaVacía()
    {
        const string input = "";
        const string expected = "";
        
        string actual= DateFormatter.ChangeFormat(input);

        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestDiezEspacios()
    {
        const string input ="          ";

        string actual = DateFormatter.ChangeFormat(input);

        Assert.That(actual, Is.Empty);
    }

    [Test]
    public void TestSeparadores()
    {
        const string input = "12-08-2003";
        const string expected = "";

        string actual = DateFormatter.ChangeFormat(input);

        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestDíaIncorrecto()
    {
        const string input = "87/10/2006";
        const string expected = "";

        string actual = DateFormatter.ChangeFormat(input);
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestMesIncorrecto()
    {
        const string input = "12/98/2006";
        const string expected = "";

        string actual = DateFormatter.ChangeFormat(input);
        Assert.That(actual, Is.EqualTo(expected));
    }

    [Test]
    public void TestAñoIncorrecto()
    {
        const string input = "87/10/hola";
        const string expected = "";

        string actual = DateFormatter.ChangeFormat(input);
        Assert.That(actual, Is.EqualTo(expected));
    }
}